# Retail Sales Performance Analysis

**Project 1 | Python, NumPy & Pandas**  
**Student:** Harsh Gupta  
**Admission No.:** 2026B15410155  
**Program:** Data Analytics  
**Dataset:** `data/01_retail_sales.csv`

## About
A student-level data analytics project that explores a synthetic retail transaction dataset to summarize revenue, product performance, customers, cities, monthly sales and payment methods.

## Project objectives
- Inspect data types, missing values and duplicate order IDs.
- Clean the dataset and fill missing City values using the most frequent city.
- Convert order dates and derive month and weekday features.
- Recalculate revenue from quantity and unit price and compare with the provided Revenue column.
- Calculate revenue, quantity and average order value.
- Analyze products, cities, months, customers, payment methods and categories.
- Identify revenue outliers using IQR and calculate statistics with NumPy.
- Export tables, cleaned data and charts.

## Folder structure
- `data/`: input dataset
- `src/`: Jupyter Notebook and Python script
- `SRS/`: Software Requirements Specification
- `outputs/`: cleaned CSV, analysis tables and PNG charts

## Dataset note
The dataset is synthetic and generated for educational use. Missing City values, duplicate order records and a few revenue inconsistencies were intentionally included to demonstrate data-cleaning steps. It does not represent a real retailer.

## How to run
### Google Colab
1. Upload the project ZIP to Google Drive and extract it, or upload the notebook and dataset separately.
2. Open `src/Retail_Sales_Performance_Analysis.ipynb` in Google Colab.
3. Ensure the folder structure is maintained so the notebook can read `data/01_retail_sales.csv`. If working in a different location, update `DATA_PATH` and `OUTPUT_DIR` in the notebook.
4. Run the notebook cells from top to bottom.

### Local Python
Install the packages if needed:
```bash
pip install pandas numpy matplotlib jupyter
```
Run the notebook in Jupyter, or run the Python script from the project root:
```bash
python src/retail_sales_analysis.py
```
The script expects the dataset at `data/01_retail_sales.csv`.

## Outputs
The notebook/script saves cleaned data and summary CSV files in `outputs/`, plus charts for product revenue, monthly revenue and city revenue.

## Limitations
This is descriptive analysis of synthetic teaching data. IQR outliers are statistical flags, not automatically errors. Findings do not prove causation.
