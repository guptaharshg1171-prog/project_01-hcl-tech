# Retail Sales Performance Analysis
# Student: Harsh Gupta | Admission No.: 2026B15410155 | Program: Data Analytics

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
try:
    from IPython.display import display
except ImportError:
    display = print

ROOT = Path.cwd()
DATA_PATH = ROOT / "data" / "01_retail_sales.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH)
print("Original dataset shape:", df.shape)
display(df.head())
print("\nColumns and data types:")
display(df.dtypes.to_frame("Data Type"))
print("\nMissing values:")
display(df.isna().sum().to_frame("Missing Count"))
print("\nDuplicate Order_ID count:", df["Order_ID"].duplicated().sum())

# Clean duplicate orders using Order_ID (keep first occurrence).
df = df.drop_duplicates(subset="Order_ID", keep="first").copy()

# Fill missing City values with the most frequent city (mode), preserving categorical consistency.
city_mode = df["City"].mode(dropna=True)[0]
df["City"] = df["City"].fillna(city_mode)

# Parse date safely and add time-based features.
df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")
df["Month"] = df["Order_Date"].dt.month
df["Month_Name"] = df["Order_Date"].dt.strftime("%B")
df["Weekday"] = df["Order_Date"].dt.day_name()

# Recalculate revenue and compare against the supplied Revenue column.
df["Calculated_Revenue"] = df["Quantity"] * df["Unit_Price"]
df["Revenue_Difference"] = df["Revenue"] - df["Calculated_Revenue"]
revenue_mismatch_count = (df["Revenue_Difference"].abs() > 0.01).sum()
df["Revenue"] = df["Calculated_Revenue"]

print("Cleaned dataset shape:", df.shape)
print("Filled missing City values with mode:", city_mode)
print("Revenue mismatches before correction:", revenue_mismatch_count)

# KPI summary
total_revenue = df["Revenue"].sum()
total_quantity = df["Quantity"].sum()
average_order_value = total_revenue / df["Order_ID"].nunique()
kpi_summary = pd.DataFrame({
    "Metric": ["Total Revenue", "Total Quantity", "Average Order Value", "Unique Orders"],
    "Value": [total_revenue, total_quantity, average_order_value, df["Order_ID"].nunique()]
})
display(kpi_summary)

# Top 10 products by revenue
top_products = df.groupby("Product", as_index=False)["Revenue"].sum().sort_values("Revenue", ascending=False).head(10)
display(top_products)

# City revenue ranking
city_revenue = df.groupby("City", as_index=False)["Revenue"].sum().sort_values("Revenue", ascending=False)
display(city_revenue)

# Monthly revenue and best month
monthly_revenue = df.groupby(["Month", "Month_Name"], as_index=False)["Revenue"].sum().sort_values("Month")
best_month = monthly_revenue.loc[monthly_revenue["Revenue"].idxmax()]
display(monthly_revenue)
print("Best month:", best_month["Month_Name"], "| Revenue:", round(best_month["Revenue"], 2))

# Top 10 customers by total spending
top_customers = df.groupby("Customer_ID", as_index=False)["Revenue"].sum().sort_values("Revenue", ascending=False).head(10)
display(top_customers)

# Payment method comparison: order count and revenue
payment_summary = df.groupby("Payment_Method").agg(
    Order_Count=("Order_ID", "nunique"),
    Total_Revenue=("Revenue", "sum"),
    Average_Order_Value=("Revenue", "mean")
).sort_values("Total_Revenue", ascending=False)
display(payment_summary)

# Outliers using IQR on order revenue
q1 = df["Revenue"].quantile(0.25)
q3 = df["Revenue"].quantile(0.75)
iqr = q3 - q1
lower_bound = q1 - 1.5 * iqr
upper_bound = q3 + 1.5 * iqr
revenue_outliers = df[(df["Revenue"] < lower_bound) | (df["Revenue"] > upper_bound)].sort_values("Revenue", ascending=False)
print(f"IQR bounds: {lower_bound:.2f} to {upper_bound:.2f}; outlier records: {len(revenue_outliers)}")
display(revenue_outliers.head(15))

# Category-level summary
category_summary = df.groupby("Category").agg(
    Orders=("Order_ID", "nunique"),
    Quantity=("Quantity", "sum"),
    Revenue=("Revenue", "sum"),
    Avg_Revenue_Per_Order=("Revenue", "mean")
).sort_values("Revenue", ascending=False)
display(category_summary)

# NumPy descriptive statistics
order_revenue = df["Revenue"].to_numpy()
numpy_stats = pd.DataFrame({
    "Statistic": ["Mean", "Median", "Standard Deviation"],
    "Value": [np.mean(order_revenue), np.median(order_revenue), np.std(order_revenue)]
})
display(numpy_stats)

# Visualizations (saved to outputs)
plt.figure(figsize=(10, 5))
top_products.sort_values("Revenue").plot(kind="barh", x="Product", y="Revenue", legend=False, figsize=(10, 5))
plt.title("Top Products by Revenue")
plt.xlabel("Revenue")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "top_products_revenue.png", dpi=150)
plt.show()

plt.figure(figsize=(10, 5))
plt.plot(monthly_revenue["Month_Name"], monthly_revenue["Revenue"], marker="o")
plt.title("Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "monthly_revenue_trend.png", dpi=150)
plt.show()

city_revenue.sort_values("Revenue").plot(kind="barh", x="City", y="Revenue", legend=False, figsize=(9, 5))
plt.title("City-wise Revenue")
plt.xlabel("Revenue")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "city_revenue.png", dpi=150)
plt.show()

# Save cleaned data and analysis tables
df.to_csv(OUTPUT_DIR / "cleaned_retail_sales.csv", index=False)
tables = {
    "top_products.csv": top_products,
    "city_revenue.csv": city_revenue,
    "monthly_revenue.csv": monthly_revenue,
    "top_customers.csv": top_customers,
    "payment_summary.csv": payment_summary,
    "category_summary.csv": category_summary,
    "revenue_outliers.csv": revenue_outliers,
    "kpi_summary.csv": kpi_summary,
}
for filename, table in tables.items():
    table.to_csv(OUTPUT_DIR / filename, index=False)

# Evidence-based recommendations (generated from the computed results)
best_category = category_summary.index[0]
best_city = city_revenue.iloc[0]["City"]
best_payment = payment_summary.index[0]
best_product = top_products.iloc[0]["Product"]
print("1. Review inventory planning for the top revenue-generating category:", best_category)
print("2. Study city-level demand and delivery/inventory coverage in the highest-revenue city:", best_city)
print("3. Keep the top revenue product visible in promotions while monitoring stock:", best_product)
print("4. Ensure checkout/payment experience is reliable for the leading revenue payment method:", best_payment)
print("5. Review the flagged high/low revenue outlier orders before using them for business decisions; IQR flags are not automatically errors.")

print("Analysis complete. Tables and cleaned data saved in outputs/.")
